title: GitLab 的账户管理
date: '2019-10-11 15:01:32'
updated: '2019-10-11 15:01:32'
tags: [gitlab相关]
permalink: /articles/2019/10/11/1570777292662.html
---
使用时请不要直接通过 root 用户操作，需要先创建用户，然后通过创建的用户操作，如果你是管理员还需要为其他开发人员分配账户

## 创建用户

点击“管理区域”-->“新建用户”

![null](https://upload-images.jianshu.io/upload_images/7986413-5bf5ce4d66c3490c.png?imageMogr2/auto-orient/strip|imageView2/2/w/1200/format/webp)

## 设置账户信息
同时你可以将自己设置为管理员

![null](https://upload-images.jianshu.io/upload_images/7986413-c68b6d1f4219ce9e.png?imageMogr2/auto-orient/strip|imageView2/2/w/1200/format/webp)

## 修改用户密码

由于我们创建时并没有配置邮箱，所以还需要重新编辑用户信息并手动设置密码

![null](https://upload-images.jianshu.io/upload_images/7986413-933e634700b7c631.png?imageMogr2/auto-orient/strip|imageView2/2/w/1200/format/webp)

![null](https://upload-images.jianshu.io/upload_images/7986413-12336152195f1da2.png?imageMogr2/auto-orient/strip|imageView2/2/w/1200/format/webp)

## 退出并使用新账户登录

![null](https://upload-images.jianshu.io/upload_images/7986413-7fbad3c95b82cd2a.png?imageMogr2/auto-orient/strip|imageView2/2/w/649/format/webp)
