title: git团队开发一般步骤流程
date: '2019-10-10 15:54:36'
updated: '2019-10-10 15:54:36'
tags: [待分类]
permalink: /articles/2019/10/10/1570694076090.html
---
**1.项目组长建立仓库**
git flow init
**2.成员进行克隆**
git clone
**3.项目组长分配里程碑与议题**
**4.项目成员根据自己被分配到的任务建立分支**
git flow feature start xxx
**5.完成任务后提交pull request **
git push origin
**6.pull request **
