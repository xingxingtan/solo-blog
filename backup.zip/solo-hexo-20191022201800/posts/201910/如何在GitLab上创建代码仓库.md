title: 如何在 GitLab 上创建代码仓库
date: '2019-10-11 15:14:08'
updated: '2019-10-11 15:14:08'
tags: [gitlab相关]
permalink: /articles/2019/10/11/1570778048726.html
---
一．常规流程 → [登录、注册](https://gitlab.com/users/sign_in) （这里可能因为网络需要用一下梯子，不然有可能会卡在接收验证码上）

二．创建 GitLab 团队
![](https://img-blog.csdnimg.cn/20190720111023100.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2phY2tzaW5yb3c=,size_16,color_FFFFFF,t_70)

 

![](https://img-blog.csdnimg.cn/20190720111023179.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2phY2tzaW5yb3c=,size_16,color_FFFFFF,t_70)

* 新建工程

1.创建项目相关工程

![](https://img-blog.csdnimg.cn/20190720111023551.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2phY2tzaW5yb3c=,size_16,color_FFFFFF,t_70)

![](https://img-blog.csdnimg.cn/20190720111023547.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2phY2tzaW5yb3c=,size_16,color_FFFFFF,t_70)

2.基础设置

![](https://img-blog.csdnimg.cn/20190720111023608.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2phY2tzaW5yb3c=,size_16,color_FFFFFF,t_70)

3.添加组织成员，设置相关权限

![](https://img-blog.csdnimg.cn/20190720111023830.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2phY2tzaW5yb3c=,size_16,color_FFFFFF,t_70)

4.组织基础设置

![](https://img-blog.csdnimg.cn/20190720111024159.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2phY2tzaW5yb3c=,size_16,color_FFFFFF,t_70)

5.项目设置页面

![](https://img-blog.csdnimg.cn/20190720111024172.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2phY2tzaW5yb3c=,size_16,color_FFFFFF,t_70)

接下来介绍一下如何 clone 项目代码，分为两个部分：HTTPS、SSH
![](https://img-blog.csdnimg.cn/20190720111023893.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2phY2tzaW5yb3c=,size_16,color_FFFFFF,t_70)

（提示：如果对于 git 命令不熟悉，推荐使用可视化工具 → SourceTree）

使用HTTPS 直接复制地址，粘贴到 SourceTree 上。

![](https://img-blog.csdnimg.cn/20190720111023955.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2phY2tzaW5yb3c=,size_16,color_FFFFFF,t_70)

但，使用 HTTPS 会经常出现一种情况，老是需要输入密码，及时保存了也会弹出来，推荐使用 SSH 。

如何生成并设置SSH Key？

1.首先检查电脑检查是否已经存在SSH Key，打开电脑终端，输入以下命令:

ls -al ~/.ssh

会出现两种情况

 (1)情况一:终端出现文件id_rsa.pub 或 id_dsa.pub，则表示该电脑已经存在SSH Key，此 时可继续输入命令:

pbcopy < ~/.ssh/id_rsa.pub

这样你需要的SSH Key 就已经复制到粘贴板上了。

(2)情况二:终端未出现id_rsa.pub 或 id_dsa.pub文件，表示该电脑还没有配置SSH Key， 此时需要输入命令: ssh-keygen -t rsa -C "your_email@example.com" 默认会在相应路径下 (/your_home_path) 生成id_rsa和id_rsa.pub两个文件，此时终端会显示:Generating public/private rsa key pair.Enter file in which to save the key (/your_home_path/.ssh/id_rsa):连续回车即可，也可能会让你输入密码，密码就是你的开机密码。

2.再输入命令:ls -al ~/.ssh 就会出现id_rsa.pub 和 id_dsa.pub两个文件，然后重复情况一的步骤即输入以下命令再进行步骤3即可: pbcopy < ~/.ssh/id_rsa.pub

3.将SSH Key添加到GitLab中

打开GitLab, 登录->点击右上角的用户头像->点击settings->在settings里找到SSH的设置->点击 “ADD SSH KEY”按钮添加->将已经获得的SSH Key粘贴“Key”，标题可以随便取，这样就 保持了本地与服务器端的联系.

 

4.修改连接方式 步骤1.查看当前地址

git remote -v 若是http(s)://XXXX/XXX.git形式，则说明目前配置的连接方式为http(s) 

若是git@XXXX/XXX.git形式，则说明目前配置的连接方式为ssh 步骤2.设置新地址

git remote set-url origin [你想要设置的新地址] 步骤3.使用步骤1的方法查看是否修改成功

四、生成了 SSH key 后在gitlab 中设置的图片说明

![](https://img-blog.csdnimg.cn/20190720111024172.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2phY2tzaW5yb3c=,size_16,color_FFFFFF,t_70)

 

![](https://img-blog.csdnimg.cn/20190720111024156.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2phY2tzaW5yb3c=,size_16,color_FFFFFF,t_70)

 

![](https://img-blog.csdnimg.cn/20190720111024128.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2phY2tzaW5yb3c=,size_16,color_FFFFFF,t_70)

 

![](https://img-blog.csdnimg.cn/201907201110247.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2phY2tzaW5yb3c=,size_16,color_FFFFFF,t_70)
