title: crontab定时器入门
date: '2019-09-27 11:23:24'
updated: '2019-09-27 11:23:24'
tags: [工具]
permalink: /articles/2019/09/27/1569554604475.html
---
![](https://img.hacpai.com/bing/20190908.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

1.下载crontab工具
yum install crontab
2.编辑crontab
crontab -e
3. 查看crontab
crontab -l
4.启动crontab
service cron start

### Crontab在Linux上的结构

---

![null](https://upload-images.jianshu.io/upload_images/1156494-708aadc03b3a8d95.png?imageMogr2/auto-orient/strip|imageView2/2/w/656/format/webp)

crontab结构.png

  
从左到右依次为：  
[分钟] [小时] [每月的某一天] [每年的某一月] [每周的某一天] [执行的命令]  
**注意**：请留意每个选项的取值范围。

### 如何 添加/编辑 Crontab

---

* 添加或更新crontab中的命令

```undefined
crontab -e

```

默认情况下，系统会编辑当前登录用户的crontab命令集合。需要编辑其他用户的命令集合，需要使用到如下的命令

```undefined
crontab -u username -e

```

### 查看Crontab命令集合

---

* 查看当前系统登录用户的Crontab命令集合

```undefined
crontab -l

```

* 查看其他用户的Crontab命令集合

```undefined
crontab -u username -l

```

### 20个超实用的Crontab使用实例

---

1. 每天 02:00 执行任务

```jsx
0 2 * * * /bin/sh backup.sh

```

2. 每天 5:00和17:00执行任务

```jsx
0 5,17 * * * /scripts/script.sh

```

3. 每分钟执行一次任务  
    通常情况下，我们并没有每分钟都需要执行的脚本(默默的想到了12306--)

```jsx
  * * * * *  /scripts/script.sh

```

4. 每周日 17:00 执行任务

```undefined
0 17 * * sun  /scripts/script.sh

```

5. 每 10min 执行一次任务

```jsx
*/10 * * * * /scripts/monitor.sh

```

6. 在特定的某几个月执行任务

```jsx
  * * * jan,may,aug * /script/script.sh

```

7. 在特定的某几天执行任务

```undefined
0 17 * * sun,fri /script/scripy.sh

```

在每周五、周日的17点执行任务

8. 在某个月的第一个周日执行任务

```jsx
0 2 * * sun  [ $(date +%d) -le 07 ] && /script/script.sh

```

9. 每四个小时执行一个任务

```jsx
0 */4 * * * /scripts/script.sh

```

10. 每周一、周日执行任务

```undefined
0 4,17 * * sun,mon /scripts/script.sh

```

11. 每个30秒执行一次任务  
    我们没有办法直接通过上诉类似的例子去执行，因为最小的是1min。但是我们可以通过如下的方法。

```jsx
  * * * * * /scripts/script.sh
  * * * * *  sleep 30; /scripts/script.sh

```

12. 多个任务在一条命令中配置

```jsx
  * * * * * /scripts/script.sh; /scripts/scrit2.sh

```

13. 每年执行一次任务

```css
@yearly /scripts/script.sh

```

@yearly 类似于“0 0 1 1 *”。它会在每年的第一分钟内执行，通常我们可以用这个发送新年的问候。

14. 每月执行一次任务

```css
@yearly /scripts/script.sh

```

15. 每周执行一次任务

```css
@yearly /scripts/script.sh

```

16. 每天执行一次任务

```css
@yearly /scripts/script.sh

```

17. 每分钟执行一次任务

```css
@yearly /scripts/script.sh

```

18. 系统重启时执行

```css
@reboot /scripts/script.sh

```

19. 将 Cron 结果重定向的特定的账户  
    默认情况下，cron 只会将结果详情发送给 cron 被制定的用户。如果需要发送给其他用户，可以通过如下的方式：

```ruby
  # crontab -l
  MAIL=bob
  0 2 * * * /script/backup.sh

```

20. 将所有的 cron 命令备份到文本文件当中  
    这是一个当我们丢失了cron命令后方便快速的一个恢复方式。  
    下面是利用这个方式恢复cron的一个小例子。（看看就行~）  
    首先：检查当前的cron

```ruby
# crontab -l
MAIL=rahul
0 2 * * * /script/backup.sh

```

然后：备份cron到文件中

```ruby
# crontab -l > cron-backup.txt
# cat cron-backup.txt
MAIL=rahul
0 2 * * * /script/backup.sh

```

接着：移除当前的cron

```bash
# crontab -r
# crontab -l
no crontab for root

```

恢复：从text file中恢复

```ruby
# crontab cron-backup.txt
# crontab -l
MAIL=rahul
0 2 * * * /script/backup.sh
```
