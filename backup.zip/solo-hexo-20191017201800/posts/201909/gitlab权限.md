title: gitlab权限
date: '2019-09-29 12:23:22'
updated: '2019-09-29 12:23:22'
tags: [待分类]
permalink: /articles/2019/09/29/1569731002017.html
---
![image.png](https://img.hacpai.com/file/2019/09/image-9dd42a07.png)
![image.png](https://img.hacpai.com/file/2019/09/image-4ee355b0.png)
![image.png](https://img.hacpai.com/file/2019/09/image-2fdeda01.png)
![image.png](https://img.hacpai.com/file/2019/09/image-40da18af.png)
![image.png](https://img.hacpai.com/file/2019/09/image-ed5493e9.png)






