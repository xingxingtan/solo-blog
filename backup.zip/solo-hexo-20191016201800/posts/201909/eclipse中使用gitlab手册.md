title: eclipse中使用gitlab手册
date: '2019-09-30 10:09:55'
updated: '2019-09-30 10:11:16'
tags: [工具]
permalink: /articles/2019/09/30/1569809395055.html
---
![](https://img.hacpai.com/bing/20171107.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

**Gitlab在eclipse中的使用**
1.生成SSH key 
我们用的是eclipse自带的生成key的工具，windows->preferences->General->Network Connections->SSH2，点击SSH2。

 

在key management处点生成RSAkey 



后面输入key的说明和密码，密码也可以空着。点save private key. 把生成的key文件存到用户目录的.ssh目录下。（像第一张图中SSH2 Home指定的目录）



会生成两个文件，一个id_rsa是私钥，一个id_rsa.pub是公钥。

2.发布公钥到服务器
用记事本打开刚刚保存的id_rsa.pub文件，能看到如图所示的类似内容，将他们复制下来。



用你的用户登录到GitLab, Profile Settings->ssh keys->add ssh key. 给用户添加全局的公钥文件。

 

 

把刚刚复制的内容粘贴到页面上，add key。

 

3.相关的具体操作
1）在Eclipse中新建一个项目，此处新建测试用的项目是GitPro1




2）新建GitPro1项目的仓库
在项目上右键 -> Team ->Share Project -> Git -> Next

 


Create->自定义仓库名称->Finish

 

在D:\Program Files\Git\GitPro1目录下可以看到GitPro1仓库了

 

同时，eclipse中的project也建立git版本控制，此时未创建分支，处于NO-HEAD状态

 

文件夹中的”?”表示此文件夹处于untracked状态，这样就成功创建Git仓库。

3）配置.gitignore来过滤不需要上传的文件
这种情况针对带maven依赖的工程！！（因为.classpath .settings .project | clone下来时会有影响造成无法下载jar包依赖）

普通工程暂时不用过滤文件

在工程实现过程中，会生成一些中间文件，或者在项目中的部分文件是不需要进行版本管理的。对于这些文件应该对于Git来讲是透明的。Git提供这种功能，可以自己指定哪些文件可以不被管理。具体方法是在版本管理的根目录下（与.Git文件夹同级）创建一个  .gitignore（gitignore是隐藏文件，所以前面有个点）

右键工程->new file->输入.gitignore 生成.gitignore文件

 

在界面上输入.classpath .settings .project 保存。可以在仓库视图的Working Directory中看到这个文件。此时你commit时会自动过滤掉这三类文件。若本来工程下面就有这个文件里面如果有/bin/类似的文字不要删除，直接换行添加你需要过滤的文件。

 



这个在项目里看不到，可以仓库视图的work

 

4）将项目Commit到本地仓库
尝试提交GitPro1项目，右键->Team->Commit

提示验证信息，将自己用户名和邮箱填写进去，点OK. 下次就不需要填写了。

 



点击 Commit。我们就把上图中status选中的文件提交到本地git库中了。这些文件从此受git的版本监控了。并且提交注释为version1.0（这个以后用到，当作状态标记）。

接下来打开git repositories视图（Window->show view->other->Git->Git Repositories->OK）

此时，来看看git repositories视图：

 

这个就是我们在本地git仓库的结构。

5）修改文件后commit
当我们修改GitTest.java的时候。文件状态会发生改变

 

 

选中修改过的文件。右击Team->commit. 提交时注释信息为”version 1.1”。

提交完成后，git状态如图

 

 

6）添加新文件后的处理
 

SecondFile.java是我新建的类，“？”表示这个文件未受git库版本监控。要想加入监控：选中这个文件，右击 team > add to index. 之后commit。

 

7）查看历史提交记录
项目->Team -> Show in history 可以查看版本历史提交记录

 

 

8）Push到Gitlab
将本地的git库中的内容push到服务器端的远程仓库

 

项目->Team -> Remote -> Push填写相关信息后 -> next -> Add All Branches Specs ->Finish

Tips: URI在登陆后的Project栏点击，复制中间的地址。

 



填写好后，点击next –>Add All Branches Spec->Finish.

 

完成后：











提示项目已经push到服务器。

我们可以在Gitlab中点击Browse Files查看已经上传的代码。

 



 

9）使用.gitkeep来追踪空的文件夹
Git会忽略空的文件夹。如果你想版本控制包括空文件夹，根据惯例会在空文件夹下放置.gitkeep文件。其实对文件名没有特定的要求。一旦一个空文件夹下有文件后，这个文件夹就会在版本控制范围内。

10）clone 在GitLab中已有项目
为演示，先删除刚刚在eclipse里创建的GitPro1项目

客户端Eclipse上，打开git Repositories视图。点击 . clone a git Repository.

 

输入信息后点击next，我们会看到服务端git库的分支master出现了



Next





点击Finish. 我们的clone就完成了。

 

现在在自己的工作空间创建了服务器端的项目。

克隆服务器端仓库后，会在本地建立一个一样的仓库，称本地仓库。

 

如果clone带有过滤文件的maven+git工程时，clone下来时是无法直接到工作空间的。需要从仓库视图里导入。

当clone下来带有过滤后的Maven+git工程时在git仓库视图右键—>Import projects—>Import as general project—>next—>finish,此时eclipse工作空间就导入了项目，但现在是没有maven的，右键工程—>Configure—>Convert to maven project，现在工作空间的工程就是一个完整的maven+git工程了。

11）新建自己的分支进行开发并push到远程分支
Team->Switch To->New Branch

 



此时，刚刚clone下来的分支已经切换成自己的分支，我们就能在自己的分支上任意开发了



在自己分支上开发，修改文件并commit提交到本地仓库。

 

接下来要push到远程的新建分支

Team->Remote->push->Next->Add Spec->Next->Finish

 

成功将自己修改后的代码提交到远程新建的自己的分支

 

现在在Gitlab上就能看到两个分支，一个master主分支（保护状态，developer无法push）和yjx新建分支

 

12）新建分支与master分支进行合并请求（Merge Request）
登陆自己的Gitlab账户。点击Project或进入工程点击Branch会看到创建合并请求的标签：

 .



点击Merge Request

 

此时，管理员登陆Gitlab后点左侧Projects->GitPro1->Merge Requests

 

管理员任何新建分支提交的代码，审阅后没有问题的情况下点击Accept Merge Request

 

此时我们看到合并到master分支后的情况

 

Tips： matser用户可以直接push到master分支。Developer无法直接push到受保护的master分支，必须先建立自己的分支，再提交，推送，请求合并。

13）退回历史版本
远程仓库和本地仓库都存放有我们提交的每一个历史版本。

打开工程的历史，在要退回的历史版本上右键reset->Hard->yes，工程就退回历史版本了

 

 

14）推送冲突的解决
对于master用户来说：

假定咱们clone到本地的工程分支保持不变是1.1版本，但是服务器远程分支已经被更新到1.3版本了，此时就会产生冲突，无法提交：

 



此时我们要将工程pull到最新 team->pull将远程的修改pull到本地git库：

点ok。你回发现工作空间的项目出现冲突的标志。



此时，选择冲突的文件GitTest.java右击，Team > merge tool .



选择第二项，ok。

 

根据比较修改左边的文件，也就是你工作空间中的文件。解决完冲突之后。保存。如图状态。

 

现在你可以提交这个文件了。选中GitTest.java 右击team > add to index .

此时工作空间中的图标有所变化。

 

当出现灰色的雪花符号时，你就可以进行提交并 push到服务器端。

commit 状态

 

之后，push。

现在成功push

 



 

15）自建分支开发前获取远程master更新并与本地合并
作为developer用户在自己的分支上先右键->fetch from upstream将远程master分支的最新版本更新到本地，ok。 接着右键->team->merge ,如图选择下面远程仓库的master分支，Merge，选择最新的版本，点ok，则当前自己的分支已更新到远程master分支同步。




Merge之后当前分支已经和服务器端远程仓库的master分支一致了，就可以继续开发了。

 

16）自建工程push到远端后本地git没有远端追踪的解决方案
这种情况发生在我们自己建立的工程，并且在该工程下继续开发时。本地新建工程后

 

进行commit-push，将代码推送到服务器端后，会发现本地git视图的远程追踪是空的，只有本地追踪。此时，如果有人参与该工程，并且远端分支修改，你需要fetch时，在IDE中时无法操作拉远程分支的。


如何解决这个问题？我们切到git仓库视图，在下图中的Remotes仓库的小图标上右键，点击Create Remote，再点击configure fetch，点ok。




然后将服务器web端的工程URL粘贴在下图中，并填上主机地址。点finish。接下来再点击左下角的save and fetch。然后大功告成，最后一张图中我们就看到方框中远程追踪已经出现了，接下来你就可以任意的fetch远程分支了。

 





 
————————————————
原文链接：https://blog.csdn.net/Adelly/article/details/79099772
